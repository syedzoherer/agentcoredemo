# Don't add async module imports here
from .resource import SlackAppResource

__all__ = [
    "SlackAppResource",
]
